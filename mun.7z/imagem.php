<?php
 
//Carregar imagem
$rImg = ImageCreateFromJPEG("mun.jpeg");
 
//Definir cor
$cor = imagecolorallocate($rImg, 132, 112, 255);
//Escrever nome
//imagestring($rImg,5,226,354,urldecode($_GET['nome']),$cor);
imagettftext ( $rImg, 12, 0, 226, 367, $cor, 'Lucida Handwriting.ttf' , urldecode($_GET['name']));
imagettftext ( $rImg, 12, 0, 226, 427, $cor, 'Lucida Handwriting.ttf' , urldecode($_GET['college']));
//Header e output
	 imagejpeg($rImg,"./Images/".urldecode($_GET['name']).urldecode($_GET['college']).".jpeg");
imagejpeg($rImg);
 
?>;