<html>
<head>
<title> Certificate Acquisition Portal</title>
</head>
<body>
<h1 style="text-align:center"> Certificate Acquisition Portal </h1>
<form name="certificate" action="details.php" method="POST">
<table>
<tr>
<td> Enter Certificate Number </td>
<td> <input id="cno" name="cno" type="text"></td>
</tr>
<tr> 
<td> Submit </td>
<td> <input type="submit" value="Submit"></td>
</tr>
</table>
</form>
</body>
</html>